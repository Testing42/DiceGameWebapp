<?php
include_once "config.php";

if(isset($_POST['but_submit'])){

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    

    $query = "SELECT * FROM users WHERE username='".$username."'";
    $tbl = mysqli_query($con,$query);
    $row = mysqli_fetch_array($tbl);

    $hashed_password =$row['password'];

    if (($username != "" && $hashed_password != "") && password_verify($password, $hashed_password)){
        
        $_SESSION['username'] = $username;
        header('Location: ../home.php');
        
    }
    else{
        header('Location: ../incorrect.php');
    }

}


    


?>