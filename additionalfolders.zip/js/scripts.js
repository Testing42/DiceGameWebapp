function Disable_Space() {
    if (event.keyCode == 32) {
        event.returnValue = false;
        return false;
    }
}

function Random() {
    var x = Math.floor((Math.random() * 6) + 1);
    document.getElementById("result").innerHTML = x;
}